package com.dwb.qqclient.service;

import com.dwb.qqcommon.Message;
import com.dwb.qqcommon.MessageType;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

public class ClientConnectServerThread extends Thread{

    private Socket socket;
    public ClientConnectServerThread(Socket socket){
        this.socket=socket;
    }

    public Socket getSocket() {
        return socket;
    }

    @Override
    public void run() {
         while (true){
             try {
                 ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                 Message ms = (Message)ois.readObject();
                 if (ms.getMesType().equals(MessageType.MESSAGE_RET_ONLINE_FRIEND)){
                     String[] s = ms.getContent().split(" ");
                     System.out.println("\n=========当前在线用户列表=========");
                     for (int i =0;i< s.length;i++){
                         System.out.println("\t\t\t 用户"+s[i]);
                     }
                 } else if (ms.getMesType().equals(MessageType.MESSAGE_COMM_MES)) {
                     System.out.println("\n"+ms.getSender()+"对你说："+ms.getContent());
                 } else if (ms.getMesType().equals(MessageType.MESSAGE_TO_ALL_MES)) {
                     System.out.println("\n"+ms.getSender()+"对大家说："+ms.getContent());
                 } else if (ms.getMesType().equals(MessageType.MESSAGE_FILE_MES)) {
                     System.out.println("\n"+"用户"+ms.getSender()+"发送文件"+ms.getSrc()+"到我的目录"+ms.getDest());
                     FileOutputStream fileOutputStream = new FileOutputStream(ms.getDest());
                     fileOutputStream.write(ms.getFileBytes());
                     fileOutputStream.close();
                     System.out.println("保存文件成功");
                 } else if (ms.getMesType().equals(MessageType.MESSAGE_AMENT_SUCCED)) {


                 } else {
                     System.out.println("其他类型暂时不处理");
                 }
             } catch (Exception e) {
                 throw new RuntimeException(e);
             }

         }
    }
}
