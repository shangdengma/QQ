package com.dwb.qqclient.service;

import com.dwb.qqcommon.Message;
import com.dwb.qqcommon.MessageType;

import java.io.IOException;
import java.io.ObjectOutputStream;

public class MessageClientService {
    public void sendMessageToOne(String content,String senderId,String getterId){
        Message message = new Message();
        message.setSender(senderId);
        message.setGetter(getterId);
        message.setContent(content);
        message.setMesType(MessageType.MESSAGE_COMM_MES);
        message.setSendTime(new java.util.Date().toString());

        try {
            ObjectOutputStream oos = new ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServerThread(senderId).getSocket().getOutputStream());
            oos.writeObject(message);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
    public void sendMessageToAll(String content,String senderId){
        Message message = new Message();
        message.setContent(content);
        message.setSender(senderId);
        message.setMesType(MessageType.MESSAGE_TO_ALL_MES);
        message.setSendTime(new java.util.Date().toString());
        try {
            ObjectOutputStream oos = new ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServerThread(senderId).getSocket().getOutputStream());
            oos.writeObject(message);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
