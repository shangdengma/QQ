package com.dwb.qqframe;

import com.dwb.qqserver.service.QQServer;

public class QQframe {
    public static void main(String[] args) {
        new QQServer();
    }
}
