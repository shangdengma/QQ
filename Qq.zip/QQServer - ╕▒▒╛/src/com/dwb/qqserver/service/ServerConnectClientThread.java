package com.dwb.qqserver.service;

import com.dwb.DAO.dao.BasicDAO;
import com.dwb.qqcommon.Message;
import com.dwb.qqcommon.MessageType;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;

public class ServerConnectClientThread extends Thread{
    private Socket socket;
    private String userId;
    public ServerConnectClientThread(Socket socket,String userId){
        this.socket=socket;
        this.userId=userId;

    }

    public Socket getSocket() {
        return socket;
    }

    @Override
    public void run() {
        while(true){
            try {
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                Message message =(Message) ois.readObject();
                if (message.getMesType().equals(MessageType.MESSAGE_GET_ONLINE_FRIEND)){
                    System.out.println(message.getSender()+"读取在线人数列表");
                    String onlineUser = ManageClientThreads.getOnlineUser();
                    Message message2 = new Message();
                    message2.setMesType(MessageType.MESSAGE_RET_ONLINE_FRIEND);
                    message2.setContent(onlineUser);
                    message2.setGetter(message.getSender());
                    ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                    oos.writeObject(message2);
                } else if (message.getMesType().equals(MessageType.MESSAGE_CLIENT_EXIT)) {
                    System.out.println("用户"+message.getSender()+"退出系统");
                    ManageClientThreads.removeServerConnectClientThread(message.getSender());
                    socket.close();
                    break;
                } else if (message.getMesType().equals(MessageType.MESSAGE_COMM_MES)) {
                    ServerConnectClientThread serverConnectClientThread = ManageClientThreads.getServerConnectClientThread(message.getGetter());
                    ObjectOutputStream oos = new ObjectOutputStream(serverConnectClientThread.getSocket().getOutputStream());


                    oos.writeObject(message);
                    System.out.println(message.getSendTime()+" " +
                            "" +
                            ""+message.getSender()+"给"+message.getGetter()+"发送一条私信");
                } else if (message.getMesType().equals(MessageType.MESSAGE_TO_ALL_MES)) {
                    System.out.println(message.getSendTime()+" "+message.getSender()+"群发了一条消息");
                    HashMap<String, ServerConnectClientThread> hm = ManageClientThreads.getHm();
                    Iterator<String> iterator = hm.keySet().iterator();
                    while(iterator.hasNext()){
                        String s = iterator.next().toString();
                        if (!(s.equals(message.getSender()))){
                            ServerConnectClientThread serverConnectClientThread = hm.get(s);
                            ObjectOutputStream oos = new ObjectOutputStream(serverConnectClientThread.getSocket().getOutputStream());
                            oos.writeObject(message);
                        }

                    }
                }else if (message.getMesType().equals(MessageType.MESSAGE_FILE_MES)){
                    ServerConnectClientThread serverConnectClientThread = ManageClientThreads.getServerConnectClientThread(message.getGetter());
                    ObjectOutputStream oos = new ObjectOutputStream(serverConnectClientThread.getSocket().getOutputStream());
                    oos.writeObject(message);
                    System.out.println(message.getSendTime()+"  "+"用户"+message.getSender()+"给用户"+message.getGetter()+"发送文件");
                } else if (message.getMesType().equals(MessageType.MESSAGE_AMENT_PWD)) {
                    BasicDAO<Object> objectBasicDAO = new BasicDAO<>();
                    int update = objectBasicDAO.update("update user_information set passwd=? where userId=?", message.getNewPwd(), message.getSender());
                    if (update>0){
                        ServerConnectClientThread serverConnectClientThread = ManageClientThreads.getServerConnectClientThread(message.getSender());
                        ObjectOutputStream oos = new ObjectOutputStream(serverConnectClientThread.getSocket().getOutputStream());
                        Message message1 = new Message();
                        message1.setMesType(MessageType.MESSAGE_AMENT_SUCCED);
                        oos.writeObject(message1);
                    }
                } else {
                    System.out.println("other type");
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }


        }
    }
}
