package com.dwb.qqserver.service;

import com.dwb.DAO.dao.BasicDAO;
import com.dwb.qqcommon.Message;
import com.dwb.qqcommon.MessageType;
import com.dwb.qqcommon.User;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class QQServer {
    private ServerSocket ss = null;


    private boolean checkUser(String userId,String pwd){
        BasicDAO<User> objectBasicDAO = new BasicDAO<>();
        String sql = "select * from user_information where userId=?";

        User o = objectBasicDAO.querySingle(sql, User.class, userId);

        if (o==null){
            return false;

        }
        else{

            if (o.getPasswd().equals(pwd)){

                return true;
            }
            else {
                return false;
            }

        }

    }
    public QQServer(){
        try {
            new Thread(new SendNewsToALL()).start();
            ss = new ServerSocket(9999);
            while (true){
                Socket socket = ss.accept();
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                User u = (User) ois.readObject();
                Message message = new Message();
                if (checkUser(u.getUserId(), u.getPasswd())){
                    message.setMesType(MessageType.MESSAGE_LOGIN_SUCCEED);
                    oos.writeObject(message);
                    ServerConnectClientThread serverConnectClientThread = new ServerConnectClientThread(socket, u.getUserId());
                    serverConnectClientThread.start();
                    ManageClientThreads.addClientThread(u.getUserId(), serverConnectClientThread);
                    System.out.println("用户"+u.getUserId()+"登录成功");
                }else{
                    System.out.println("用户"+u.getUserId()+"登录失败");
                    message.setMesType(MessageType.MESSAGE_LOGIN_FAIL);
                    oos.writeObject(message);
                    socket.close();
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally {
            try {
                ss.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

    }
}
