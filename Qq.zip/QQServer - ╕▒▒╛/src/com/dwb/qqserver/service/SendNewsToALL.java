package com.dwb.qqserver.service;

import com.dwb.qqcommon.Message;
import com.dwb.qqcommon.MessageType;
import com.dwb.utils.Utility;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class SendNewsToALL implements Runnable{
    @Override
    public void run() {
        while(true){
            System.out.println("请输入服务器要推送的新闻[输入exit退出推送服务]：");
            String news = Utility.readString(100);
            if (news.equals("exit")){
                break;
            }
            Message message = new Message();
            message.setSender("服务器");
            message.setContent(news);
            message.setMesType(MessageType.MESSAGE_TO_ALL_MES);
            message.setSendTime(new Date().toString());
            System.out.println("服务器推送消息给所有人");
            HashMap<String, ServerConnectClientThread> hm = ManageClientThreads.getHm();
            Iterator<String> iterator = hm.keySet().iterator();
            while (iterator.hasNext()){
                String onlineUser = iterator.next().toString();
                ObjectOutputStream oos = null;
                try {
                    oos = new ObjectOutputStream(hm.get(onlineUser).getSocket().getOutputStream());
                    oos.writeObject(message);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

            }
        }

    }
}
